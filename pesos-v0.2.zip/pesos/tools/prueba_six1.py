"""
Prueba mínima de la interfaz MT-SICS del ACT350 desde una PC en la misma red.
Uso:  python prueba_six1.py 192.168.0.10 81
Cierre antes la página web del ACT350 (solo admite una conexión).
"""
import socket
import sys
import time

CAMPOS = ["Id", "Sts", "MinW", "CoZ", "Rep", "Calc", "PosE", "StepE", "MarkE",
          "Range", "TM", "G (bruto)", "N (neto)", "T (tara)", "Unidad"]

def leer_linea(s):
    buf = b""
    while not buf.endswith(b"\n"):
        c = s.recv(1)
        if not c:
            raise ConnectionError("El ACT350 cerró la conexión")
        buf += c
    return buf

host = sys.argv[1] if len(sys.argv) > 1 else "192.168.0.10"
port = int(sys.argv[2]) if len(sys.argv) > 2 else 81

with socket.create_connection((host, port), timeout=3) as s:
    s.settimeout(2)
    for cmd in ["I3", "I4", "SIX1", "SIX1", "SIX1"]:
        s.sendall((cmd + "\r\n").encode("ascii"))
        raw = leer_linea(s)
        print(f"Enviado {cmd!r:8} Recibido {raw!r}")
        t = raw.decode("ascii", "replace").split()
        if cmd == "SIX1" and t and t[0] == "SIX1":
            if len(t) != 15:
                print(f"   AVISO: se esperaban 15 campos y llegaron {len(t)}")
            for nombre, valor in zip(CAMPOS, t):
                print(f"   {nombre:10} = {valor}")
        time.sleep(0.3)
