package com.sic.pesos.sics

/**
 * Interpretación de respuestas MT-SICS del ACT350 (manual 30303895 R04, apéndice B).
 *
 * Formato SIX1 (B.3.2):
 *   SIX1 Sts MinW CoZ Rep Calc PosE StepE MarkE Range TM G N T Unit
 *   idx:  0   1    2   3   4    5    6     7     8     9  10 11 12 13 14
 * Ejemplo del manual (B.3.4):
 *   SIX1 S 0 Z N R 0 0 0 1 N 0.00 0.00 0.00 kg
 *
 * Los valores de peso vienen justificados a la derecha con espacios, por eso se
 * separa por "uno o más espacios". Si la respuesta no trae exactamente 15 campos
 * NO se intenta adivinar la posición del bruto/neto/tara: el peso queda como no válido.
 */

enum class WeightStatus(val code: String, val label: String) {
    STABLE("S", "Estable"),
    DYNAMIC("D", "Inestable"),
    OVERLOAD("+", "Sobrecarga"),
    UNDERLOAD("-", "Bajo cero"),
    INCLINATION("/", "Inclinación"),
    INVALID("I", "Valor inválido"),
    UNKNOWN("?", "Desconocido");

    companion object {
        fun of(code: String): WeightStatus = entries.firstOrNull { it.code == code } ?: UNKNOWN
    }
}

data class Six1Reading(
    val raw: String,
    val status: WeightStatus,
    /** CoZ: true = dentro de ±¼ d del cero bruto. */
    val centerOfZero: Boolean?,
    /** Rep: true = valor nuevo (N), false = repetido (R). */
    val newValue: Boolean?,
    /** TM: N sin tara, M tara medida, P tara predeterminada. */
    val tareMode: String?,
    val gross: Double?,
    val net: Double?,
    val tare: Double?,
    val unit: String?,
    /** Decimales con que el ACT350 envía el peso (ayuda a deducir la división). */
    val decimals: Int?,
) {
    val complete: Boolean
        get() = gross != null && net != null && tare != null && unit != null
}

sealed class SicsResponse {
    abstract val raw: String

    data class Six1(val reading: Six1Reading) : SicsResponse() {
        override val raw: String get() = reading.raw
    }

    /** ES, ET, EL, EI (B.2.3.2). */
    data class Error(val code: String, override val raw: String) : SicsResponse() {
        val meaning: String
            get() = when (code) {
                "ES" -> "Error de sintaxis: el ACT350 no reconoció el comando"
                "ET" -> "Error de transmisión"
                "EL" -> "Error lógico: parámetro incorrecto"
                "EI" -> "Error interno: no se puede ejecutar ahora"
                else -> "Error"
            }
    }

    data class Other(override val raw: String) : SicsResponse()
}

object SicsParser {
    const val SIX1_FIELD_COUNT = 15
    val SIX1_FIELD_NAMES = listOf(
        "Id", "Sts", "MinW", "CoZ", "Rep", "Calc", "PosE", "StepE", "MarkE",
        "Range", "TM", "G (bruto)", "N (neto)", "T (tara)", "Unidad",
    )
    private val ERROR_CODES = setOf("ES", "ET", "EL", "EI")
    private val WHITESPACE = Regex("\\s+")

    fun tokens(line: String): List<String> {
        val clean = line.trim()
        return if (clean.isEmpty()) emptyList() else clean.split(WHITESPACE)
    }

    fun parse(line: String): SicsResponse {
        val t = tokens(line)
        if (t.isEmpty()) return SicsResponse.Other(line)
        if (t.size == 1 && t[0] in ERROR_CODES) return SicsResponse.Error(t[0], line)
        if (t[0] != "SIX1" || t.size < 2) return SicsResponse.Other(line)

        val status = WeightStatus.of(t[1])
        if (t.size != SIX1_FIELD_COUNT) {
            // Respuesta corta o con campos inesperados: se conserva el estado, pero sin pesos.
            return SicsResponse.Six1(
                Six1Reading(line, status, null, null, null, null, null, null, null, null)
            )
        }

        val gross = t[11].toDoubleOrNull()
        val net = t[12].toDoubleOrNull()
        val tare = t[13].toDoubleOrNull()
        val unit = t[14].takeIf { u -> u.any { it.isLetter() } }
        val weightsOk = gross != null && net != null && tare != null && unit != null

        return SicsResponse.Six1(
            Six1Reading(
                raw = line,
                status = status,
                centerOfZero = when (t[3]) { "Z" -> true; "N" -> false; else -> null },
                newValue = when (t[4]) { "N" -> true; "R" -> false; else -> null },
                tareMode = t[10],
                gross = if (weightsOk) gross else null,
                net = if (weightsOk) net else null,
                tare = if (weightsOk) tare else null,
                unit = if (weightsOk) unit else null,
                decimals = if (weightsOk) decimalsOf(t[11]) else null,
            )
        )
    }

    /** Tabla campo → valor recibido, para la pantalla "Prueba de conexión". */
    fun describeSix1(line: String): List<Pair<String, String>> {
        val t = tokens(line)
        if (t.firstOrNull() != "SIX1") return listOf("Respuesta" to "No es SIX1: '${t.joinToString(" ")}'")
        val rows = t.mapIndexed { i, v -> (SIX1_FIELD_NAMES.getOrNull(i) ?: "Extra $i") to v }
        return if (t.size == SIX1_FIELD_COUNT) rows
        else rows + ("Aviso" to "Se esperaban $SIX1_FIELD_COUNT campos y llegaron ${t.size}")
    }

    fun toKg(value: Double, unit: String): Double? = when (unit.lowercase()) {
        "kg" -> value
        "g" -> value / 1000.0
        "t" -> value * 1000.0
        "lb" -> value * 0.45359237
        "oz" -> value * 0.028349523125
        else -> null
    }

    /** Muestra CR y LF de forma visible: "SIX1 S ...kg\r\n". */
    fun visible(raw: String): String = raw.replace("\r", "\\r").replace("\n", "\\n")

    private fun decimalsOf(token: String): Int {
        val dot = token.indexOf('.')
        return if (dot < 0) 0 else token.length - dot - 1
    }
}
