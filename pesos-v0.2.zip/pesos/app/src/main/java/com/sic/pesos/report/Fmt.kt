package com.sic.pesos.report

import com.sic.pesos.data.Weighing
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Fmt {
    private val locale = Locale("es", "EC")
    private fun f(p: String) = SimpleDateFormat(p, locale)

    fun date(ms: Long): String = f("dd/MM/yyyy").format(Date(ms))
    fun time(ms: Long): String = f("HH:mm:ss").format(Date(ms))
    fun dateTime(ms: Long): String = f("dd/MM/yyyy HH:mm:ss").format(Date(ms))
    fun fileStamp(ms: Long): String = f("yyyyMMdd_HHmm").format(Date(ms))

    fun kg(v: Double, decimals: Int): String =
        BigDecimal(v).setScale(decimals, RoundingMode.HALF_UP).toPlainString()

    /** Suma exacta de los valores tal como se muestran (sin error de coma flotante). */
    fun total(list: List<Weighing>, decimals: Int): String =
        list.fold(BigDecimal.ZERO) { acc, w -> acc + BigDecimal(w.kg).setScale(decimals, RoundingMode.HALF_UP) }
            .setScale(decimals, RoundingMode.HALF_UP).toPlainString()
}
