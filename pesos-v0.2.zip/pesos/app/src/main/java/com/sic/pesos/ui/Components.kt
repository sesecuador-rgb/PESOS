package com.sic.pesos.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Pal {
    val Bg = Color(0xFFE9EDF1)
    val Panel = Color(0xFFFFFFFF)
    val Ink = Color(0xFF16222E)
    val Muted = Color(0xFF5B6B7A)
    val Line = Color(0xFFD3DAE1)
    val Blue = Color(0xFF0B4F8A)
    val Readout = Color(0xFF0F2A44)
    val Green = Color(0xFF1FA35B)
    val Amber = Color(0xFFD98A00)
    val Red = Color(0xFFC0392B)
    val LedOff = Color(0xFF3A4652)
}

val PesosColors = lightColorScheme(
    primary = Pal.Blue,
    onPrimary = Color.White,
    secondary = Pal.Green,
    error = Pal.Red,
    background = Pal.Bg,
    surface = Pal.Panel,
    onSurface = Pal.Ink,
)

/** Tipografía tabular para cifras de peso, como el visor de una balanza. */
val Digits = FontFamily.Monospace

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Pal.Panel)
            .border(1.dp, Pal.Line, RoundedCornerShape(10.dp))
            .padding(padding),
        content = content,
    )
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier
            .clip(RoundedCornerShape(50))
            .background(color)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
    )
}

/** LED verde que se enciende unos segundos cada vez que se captura una pesada. */
@Composable
fun CaptureLed(on: Boolean, size: Dp = 52.dp) {
    val core by animateColorAsState(if (on) Pal.Green else Pal.LedOff, label = "led")
    val glow = if (on) Color(0xFFB8F5CF) else Color(0xFF5A6773)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(glow, core)))
                .border(3.dp, Color(0xFF1B2733), CircleShape)
        )
        Text(
            if (on) "Capturado" else "Captura",
            color = if (on) Pal.Green else Pal.Muted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier, big: Boolean = false) {
    Column(modifier) {
        Text(label, color = Pal.Muted, fontSize = 14.sp)
        Text(
            value,
            fontFamily = Digits,
            fontWeight = FontWeight.Bold,
            fontSize = if (big) 34.sp else 26.sp,
            color = Pal.Ink,
        )
    }
}

@Composable
fun TableHeader(cols: List<Pair<String, Float>>) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFFE3E9EF))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        cols.forEachIndexed { i, (t, w) ->
            Text(
                t, Modifier.weight(w), fontWeight = FontWeight.Bold, color = Pal.Ink, fontSize = 15.sp,
                textAlign = if (i == cols.lastIndex) TextAlign.End else TextAlign.Start,
            )
        }
    }
}

@Composable
fun TableRow(cells: List<Pair<String, Float>>, highlight: Boolean = false) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (highlight) Color(0xFFE6F6EC) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        cells.forEachIndexed { i, (t, w) ->
            Text(
                t, Modifier.weight(w), color = Pal.Ink, fontSize = 17.sp,
                fontFamily = if (i == cells.lastIndex) Digits else FontFamily.Default,
                fontWeight = if (i == cells.lastIndex) FontWeight.Bold else FontWeight.Normal,
                textAlign = if (i == cells.lastIndex) TextAlign.End else TextAlign.Start,
            )
        }
    }
}

@Composable
fun PesosTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PesosColors, content = content)
}
