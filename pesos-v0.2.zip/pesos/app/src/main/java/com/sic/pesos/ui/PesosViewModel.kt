package com.sic.pesos.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sic.pesos.cycle.CycleDetector
import com.sic.pesos.cycle.CyclePhase
import com.sic.pesos.cycle.CycleSnapshot
import com.sic.pesos.cycle.WeighingSession
import com.sic.pesos.data.PesosDb
import com.sic.pesos.data.TestRecord
import com.sic.pesos.data.Weighing
import com.sic.pesos.data.WeightMode
import com.sic.pesos.report.PdfReport
import com.sic.pesos.settings.AppSettings
import com.sic.pesos.settings.Settings
import com.sic.pesos.sics.ClientEvent
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.SicsClient
import com.sic.pesos.sics.SicsParser
import com.sic.pesos.sics.SicsResponse
import com.sic.pesos.sics.Six1Reading
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

enum class Screen { MAIN, HISTORY, HISTORY_DETAIL, SETTINGS, DIAGNOSTICS }

sealed class DialogState {
    data class FinishWithLoad(val maxStableKg: Double?) : DialogState()
    data class ConfirmClear(val count: Int) : DialogState()
    data class ConfirmDeleteTest(val test: TestRecord) : DialogState()
    data object ConfirmDeleteHistory : DialogState()
    data class ReportReady(val test: TestRecord, val file: File) : DialogState()
}

data class DiagResult(val command: String, val raw: String, val table: List<Pair<String, String>>, val atMs: Long)

data class UiState(
    val settings: Settings,
    val link: LinkState = LinkState.Disconnected,
    val reading: Six1Reading? = null,
    val readingAtMs: Long = 0,
    val lastRaw: String? = null,
    val sicsError: String? = null,
    val activeTest: TestRecord? = null,
    val weighings: List<Weighing> = emptyList(),
    val cycle: CycleSnapshot = CycleSnapshot.EMPTY,
    val ledOn: Boolean = false,
    val screen: Screen = Screen.MAIN,
    val history: List<TestRecord> = emptyList(),
    val detail: TestRecord? = null,
    val detailWeighings: List<Weighing> = emptyList(),
    val dialog: DialogState? = null,
    val message: String? = null,
    val diag: List<DiagResult> = emptyList(),
)

class PesosViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = AppSettings(app)
    private val db = PesosDb(app)
    /** Todo lo que toca detector + base de datos corre en un único hilo: sin carreras. */
    private val worker = Executors.newSingleThreadExecutor().asCoroutineDispatcher()
    private val client = SicsClient(viewModelScope)
    private val session: WeighingSession

    private val _ui: MutableStateFlow<UiState>
    val ui: StateFlow<UiState>

    private var ledJob: Job? = null

    init {
        val s = prefs.load()
        session = WeighingSession(db, CycleDetector(s.cycleConfig()))
        _ui = MutableStateFlow(UiState(settings = s))
        ui = _ui

        viewModelScope.launch { client.link.collect { l -> _ui.update { it.copy(link = l) } } }
        viewModelScope.launch(worker) { client.events.collect { handle(it) } }
        viewModelScope.launch(worker) {
            db.activeTest()?.let { t ->
                session.start(t.id, t.mode)
                publishActive(t.id)
            }
        }
        if (s.autoConnect) connect()
    }

    // ---------------- Conexión ----------------

    fun connect() {
        val s = _ui.value.settings
        client.start(s.host.trim(), s.port, s.pollMs)
    }

    fun disconnect() {
        client.stop()
        viewModelScope.launch(worker) {
            session.onLinkLost(System.currentTimeMillis())
            _ui.update { it.copy(reading = null, cycle = session.detector.snapshot()) }
        }
    }

    private fun handle(e: ClientEvent) {
        when (e) {
            is ClientEvent.Response -> {
                val saved = session.onResponse(e.timeMs, e.parsed)
                _ui.update {
                    it.copy(
                        reading = (e.parsed as? SicsResponse.Six1)?.reading,
                        readingAtMs = e.timeMs,
                        lastRaw = e.raw,
                        sicsError = (e.parsed as? SicsResponse.Error)?.let { er -> "${er.code}: ${er.meaning}" }
                            ?: (e.parsed as? SicsResponse.Other)?.let { o -> "Respuesta inesperada: ${SicsParser.visible(o.raw)}" },
                        cycle = session.detector.snapshot(),
                    )
                }
                if (saved.isNotEmpty()) {
                    session.testId?.let { publishActive(it) }
                    flashLed()
                }
            }
            is ClientEvent.LinkLost -> {
                session.onLinkLost(e.timeMs)
                _ui.update { it.copy(reading = null, cycle = session.detector.snapshot()) }
            }
        }
    }

    private fun publishActive(testId: Long) {
        val t = db.getTest(testId)
        val list = db.weighings(testId)
        _ui.update { it.copy(activeTest = t, weighings = list, cycle = session.detector.snapshot()) }
    }

    private fun flashLed() {
        ledJob?.cancel()
        ledJob = viewModelScope.launch {
            _ui.update { it.copy(ledOn = true) }
            delay(3_000)
            _ui.update { it.copy(ledOn = false) }
        }
    }

    // ---------------- Prueba ----------------

    fun setMode(mode: WeightMode) {
        if (_ui.value.activeTest != null) return
        val s = _ui.value.settings.copy(weightMode = mode)
        prefs.save(s)
        _ui.update { it.copy(settings = s) }
    }

    fun startTest() = viewModelScope.launch(worker) {
        if (session.testId != null) return@launch
        val mode = _ui.value.settings.weightMode
        val t = db.createTest(mode, System.currentTimeMillis())
        session.start(t.id, mode)
        publishActive(t.id)
    }

    fun requestFinish() {
        val snap = _ui.value.cycle
        if (snap.phase == CyclePhase.LOADED) {
            _ui.update { it.copy(dialog = DialogState.FinishWithLoad(snap.maxStableKg)) }
        } else {
            finish(saveCurrent = false)
        }
    }

    fun finish(saveCurrent: Boolean) = viewModelScope.launch(worker) {
        val id = session.testId ?: return@launch
        val now = System.currentTimeMillis()
        session.closeCycle(now, saveCurrent)
        db.finishTest(id, now)
        session.stop()
        val test = db.getTest(id) ?: return@launch
        val file = buildPdf(test)
        _ui.update {
            it.copy(
                activeTest = null, weighings = emptyList(),
                cycle = session.detector.snapshot(),
                dialog = DialogState.ReportReady(test, file),
            )
        }
    }

    fun requestClear() {
        val n = _ui.value.weighings.size
        if (n > 0) _ui.update { it.copy(dialog = DialogState.ConfirmClear(n)) }
    }

    fun clearCurrent() = viewModelScope.launch(worker) {
        val id = session.testId ?: return@launch
        db.clearWeighings(id)
        publishActive(id)
        _ui.update { it.copy(dialog = null, message = "Registros borrados") }
    }

    // ---------------- Historial y reportes ----------------

    fun openHistory() = viewModelScope.launch(worker) {
        val list = db.listTests()
        _ui.update { it.copy(history = list, screen = Screen.HISTORY) }
    }

    fun openDetail(test: TestRecord) = viewModelScope.launch(worker) {
        val list = db.weighings(test.id)
        _ui.update { it.copy(detail = db.getTest(test.id) ?: test, detailWeighings = list, screen = Screen.HISTORY_DETAIL) }
    }

    fun reportFor(test: TestRecord) = viewModelScope.launch(worker) {
        val t = db.getTest(test.id) ?: return@launch
        _ui.update { it.copy(dialog = DialogState.ReportReady(t, buildPdf(t))) }
    }

    private fun buildPdf(test: TestRecord): File {
        val s = _ui.value.settings
        return PdfReport.write(
            getApplication(), test, db.weighings(test.id), s.decimals,
            "Mettler Toledo ACT350 (${s.host}:${s.port})",
        )
    }

    fun saveReportTo(uri: Uri, file: File) = viewModelScope.launch(worker) {
        val ok = runCatching {
            getApplication<Application>().contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: error("sin destino")
        }.isSuccess
        _ui.update { it.copy(message = if (ok) "PDF guardado" else "No se pudo guardar el PDF") }
    }

    fun requestDeleteTest(test: TestRecord) {
        if (test.finishedAt == null) {
            _ui.update { it.copy(message = "Finalice la prueba en curso antes de eliminarla") }
            return
        }
        _ui.update { it.copy(dialog = DialogState.ConfirmDeleteTest(test)) }
    }

    fun deleteTest(test: TestRecord) = viewModelScope.launch(worker) {
        db.deleteTest(test.id)
        _ui.update { it.copy(dialog = null, history = db.listTests(), screen = Screen.HISTORY) }
    }

    fun requestDeleteHistory() = _ui.update { it.copy(dialog = DialogState.ConfirmDeleteHistory) }

    fun deleteHistory() = viewModelScope.launch(worker) {
        db.deleteFinishedTests()
        _ui.update { it.copy(dialog = null, history = db.listTests(), message = "Historial borrado") }
    }

    // ---------------- Ajustes ----------------

    fun saveSettings(new: Settings): String? {
        new.validate()?.let { return it }
        val old = _ui.value.settings
        val locked = _ui.value.activeTest != null
        val applied = if (locked) new.copy(weightMode = old.weightMode) else new
        prefs.save(applied)
        _ui.update { it.copy(settings = applied, message = "Ajustes guardados") }
        viewModelScope.launch(worker) { session.detector.config = applied.cycleConfig() }
        val netChanged = old.host != applied.host || old.port != applied.port || old.pollMs != applied.pollMs
        if (netChanged && client.isRunning) connect()
        return null
    }

    // ---------------- Prueba de conexión ----------------

    fun sendDiag(command: String) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        val result = runCatching { client.transact(command) }
        val d = result.fold(
            onSuccess = { raw ->
                val table = if (command == "SIX1") SicsParser.describeSix1(raw) else emptyList()
                val interp = when (val p = SicsParser.parse(raw)) {
                    is SicsResponse.Six1 -> p.reading.let { r ->
                        listOf(
                            "→ Estado" to r.status.label,
                            "→ Bruto" to "${r.gross ?: "-"} ${r.unit ?: ""}",
                            "→ Neto" to "${r.net ?: "-"} ${r.unit ?: ""}",
                            "→ Tara" to "${r.tare ?: "-"} ${r.unit ?: ""}",
                            "→ Decimales recibidos" to (r.decimals?.toString() ?: "-"),
                        )
                    }
                    is SicsResponse.Error -> listOf("→ Error" to p.meaning)
                    is SicsResponse.Other -> emptyList()
                }
                DiagResult(command, raw, table + interp, now)
            },
            onFailure = { DiagResult(command, "", listOf("Error" to (it.message ?: "sin conexión")), now) },
        )
        _ui.update { it.copy(diag = (listOf(d) + it.diag).take(10)) }
    }

    fun diagText(): String {
        val s = _ui.value
        return buildString {
            appendLine("Pesos - prueba de conexión ACT350 ${s.settings.host}:${s.settings.port}")
            s.diag.forEach { d ->
                appendLine("[${com.sic.pesos.report.Fmt.dateTime(d.atMs)}] Enviado: ${d.command}\\r\\n")
                appendLine("Recibido: ${SicsParser.visible(d.raw)}")
                d.table.forEach { (k, v) -> appendLine("  $k = $v") }
            }
        }
    }

    // ---------------- Navegación ----------------

    fun go(screen: Screen) = _ui.update { it.copy(screen = screen) }
    fun dismissDialog() = _ui.update { it.copy(dialog = null) }
    fun consumeMessage() = _ui.update { it.copy(message = null) }

    override fun onCleared() {
        client.stop()
        worker.close()
        db.close()
    }
}
