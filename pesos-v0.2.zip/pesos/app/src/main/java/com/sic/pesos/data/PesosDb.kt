package com.sic.pesos.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Almacenamiento local persistente (SQLite dentro de la tablet).
 * La columna cycle_id es UNIQUE: aunque un ciclo se intente guardar dos veces
 * (reconexión, reintento), solo queda una pesada.
 */
class PesosDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "pesos.db", null, 1), WeighingStore {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE tests(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number INTEGER NOT NULL,
                started_at INTEGER NOT NULL,
                finished_at INTEGER,
                mode TEXT NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE weighings(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_id INTEGER NOT NULL REFERENCES tests(id) ON DELETE CASCADE,
                seq INTEGER NOT NULL,
                weight_kg REAL NOT NULL,
                at_ms INTEGER NOT NULL,
                cycle_id TEXT NOT NULL UNIQUE)"""
        )
        db.execSQL("CREATE INDEX idx_weighings_test ON weighings(test_id, seq)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    // ---------- Pruebas ----------

    fun createTest(mode: WeightMode, startedAt: Long): TestRecord {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val next = db.rawQuery("SELECT COALESCE(MAX(number),0)+1 FROM tests", null)
                .use { it.moveToFirst(); it.getInt(0) }
            val id = db.insertOrThrow("tests", null, ContentValues().apply {
                put("number", next)
                put("started_at", startedAt)
                put("mode", mode.name)
            })
            db.setTransactionSuccessful()
            return TestRecord(id, next, startedAt, null, mode)
        } finally {
            db.endTransaction()
        }
    }

    fun finishTest(testId: Long, finishedAt: Long) {
        writableDatabase.update(
            "tests", ContentValues().apply { put("finished_at", finishedAt) },
            "id=?", arrayOf(testId.toString())
        )
    }

    fun activeTest(): TestRecord? =
        queryTests("WHERE t.finished_at IS NULL", null).firstOrNull()

    fun getTest(testId: Long): TestRecord? =
        queryTests("WHERE t.id=?", arrayOf(testId.toString())).firstOrNull()

    fun listTests(): List<TestRecord> = queryTests("", null)

    private fun queryTests(where: String, args: Array<String>?): List<TestRecord> =
        readableDatabase.rawQuery(
            """SELECT t.id, t.number, t.started_at, t.finished_at, t.mode,
                      COUNT(w.id), COALESCE(SUM(w.weight_kg),0)
               FROM tests t LEFT JOIN weighings w ON w.test_id = t.id
               $where
               GROUP BY t.id ORDER BY t.started_at DESC""",
            args
        ).use { c ->
            val out = ArrayList<TestRecord>()
            while (c.moveToNext()) {
                out += TestRecord(
                    id = c.getLong(0),
                    number = c.getInt(1),
                    startedAt = c.getLong(2),
                    finishedAt = if (c.isNull(3)) null else c.getLong(3),
                    mode = runCatching { WeightMode.valueOf(c.getString(4)) }.getOrDefault(WeightMode.GROSS),
                    count = c.getInt(5),
                    totalKg = c.getDouble(6),
                )
            }
            out
        }

    fun deleteTest(testId: Long) {
        writableDatabase.delete("tests", "id=?", arrayOf(testId.toString()))
    }

    /** Borra todo el historial terminado (no toca la prueba en curso). */
    fun deleteFinishedTests() {
        writableDatabase.delete("tests", "finished_at IS NOT NULL", null)
    }

    // ---------- Pesadas ----------

    fun weighings(testId: Long): List<Weighing> =
        readableDatabase.rawQuery(
            "SELECT id, test_id, seq, weight_kg, at_ms, cycle_id FROM weighings WHERE test_id=? ORDER BY seq",
            arrayOf(testId.toString())
        ).use { c ->
            val out = ArrayList<Weighing>()
            while (c.moveToNext()) {
                out += Weighing(c.getLong(0), c.getLong(1), c.getInt(2), c.getDouble(3), c.getLong(4), c.getString(5))
            }
            out
        }

    /** Botón "Borrar registros": vacía las pesadas de la prueba; la numeración vuelve a 1. */
    fun clearWeighings(testId: Long) {
        writableDatabase.delete("weighings", "test_id=?", arrayOf(testId.toString()))
    }

    override fun saveWeighing(testId: Long, cycleId: String, kg: Double, atMs: Long): Weighing? {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val exists = db.rawQuery("SELECT 1 FROM weighings WHERE cycle_id=?", arrayOf(cycleId))
                .use { it.moveToFirst() }
            if (exists) return null
            val seq = db.rawQuery(
                "SELECT COALESCE(MAX(seq),0)+1 FROM weighings WHERE test_id=?", arrayOf(testId.toString())
            ).use { it.moveToFirst(); it.getInt(0) }
            val id = db.insertWithOnConflict("weighings", null, ContentValues().apply {
                put("test_id", testId)
                put("seq", seq)
                put("weight_kg", kg)
                put("at_ms", atMs)
                put("cycle_id", cycleId)
            }, SQLiteDatabase.CONFLICT_IGNORE)
            if (id == -1L) return null
            db.setTransactionSuccessful()
            return Weighing(id, testId, seq, kg, atMs, cycleId)
        } finally {
            db.endTransaction()
        }
    }
}
