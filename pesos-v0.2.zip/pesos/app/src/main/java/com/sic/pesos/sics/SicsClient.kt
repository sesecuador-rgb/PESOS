package com.sic.pesos.sics

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.NoRouteToHostException
import java.net.Socket
import java.net.SocketTimeoutException
import kotlin.coroutines.coroutineContext

sealed class LinkState {
    data object Disconnected : LinkState()
    data class Connecting(val target: String) : LinkState()
    data class Connected(val target: String) : LinkState()
    data class Retrying(val target: String, val reason: String, val retryInMs: Long) : LinkState()
}

sealed class ClientEvent {
    /** raw incluye el CR LF tal como llegó. */
    data class Response(val timeMs: Long, val raw: String, val parsed: SicsResponse) : ClientEvent()
    data class LinkLost(val timeMs: Long, val reason: String) : ClientEvent()
}

/**
 * Conexión MT-SICS por socket TCP (apéndice B.1: puerto 81, una sola conexión).
 * Consulta SIX1 + CR LF periódicamente. Un Mutex garantiza que haya un solo
 * comando en vuelo, de modo que los comandos manuales de la pantalla de prueba
 * no se mezclan con el sondeo.
 */
class SicsClient(private val scope: CoroutineScope) {

    private val ioMutex = Mutex()
    private var socket: Socket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var job: Job? = null

    private val _link = MutableStateFlow<LinkState>(LinkState.Disconnected)
    val link: StateFlow<LinkState> = _link

    private val _events = MutableSharedFlow<ClientEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<ClientEvent> = _events

    fun start(host: String, port: Int, pollMs: Long) {
        stop()
        job = scope.launch(Dispatchers.IO) { runLoop(host, port, pollMs) }
    }

    fun stop() {
        job?.cancel()
        job = null
        closeSocket()
        _link.value = LinkState.Disconnected
    }

    val isRunning: Boolean get() = job?.isActive == true

    private suspend fun runLoop(host: String, port: Int, pollMs: Long) {
        val target = "$host:$port"
        var backoff = 1_000L
        while (coroutineContext.isActive) {
            _link.value = LinkState.Connecting(target)
            try {
                val s = Socket()
                s.tcpNoDelay = true
                s.keepAlive = true
                s.soTimeout = READ_TIMEOUT_MS
                s.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
                ioMutex.withLock {
                    socket = s
                    input = BufferedInputStream(s.getInputStream())
                    output = s.getOutputStream()
                }
                _link.value = LinkState.Connected(target)
                backoff = 1_000L

                while (coroutineContext.isActive) {
                    val raw = transact("SIX1")
                    _events.emit(
                        ClientEvent.Response(System.currentTimeMillis(), raw, SicsParser.parse(raw))
                    )
                    delay(pollMs)
                }
            } catch (e: CancellationException) {
                closeSocket()
                throw e
            } catch (e: Exception) {
                closeSocket()
                val reason = describe(e)
                _events.emit(ClientEvent.LinkLost(System.currentTimeMillis(), reason))
                _link.value = LinkState.Retrying(target, reason, backoff)
                delay(backoff)
                backoff = (backoff * 2).coerceAtMost(5_000L)
            }
        }
    }

    /** Envía un comando MT-SICS (se agrega CR LF) y devuelve la línea recibida con su CR LF. */
    suspend fun transact(command: String): String = withContext(Dispatchers.IO) {
        ioMutex.withLock {
            val out = output ?: throw IOException("Sin conexión con el ACT350")
            val inp = input ?: throw IOException("Sin conexión con el ACT350")
            while (inp.available() > 0) inp.read() // descarta restos de respuestas viejas
            out.write("$command\r\n".toByteArray(Charsets.US_ASCII))
            out.flush()
            readLine(inp)
        }
    }

    private fun readLine(inp: InputStream): String {
        val sb = StringBuilder()
        while (true) {
            val b = inp.read()
            if (b == -1) throw IOException("El ACT350 cerró la conexión")
            sb.append(b.toChar())
            if (b == '\n'.code) return sb.toString()
            if (sb.length > 512) throw IOException("Respuesta demasiado larga sin CR LF")
        }
    }

    private fun closeSocket() {
        try { socket?.close() } catch (_: Exception) { }
        socket = null
        input = null
        output = null
    }

    private fun describe(e: Exception): String = when (e) {
        is SocketTimeoutException -> "Sin respuesta del ACT350 (tiempo agotado)"
        is ConnectException -> "Conexión rechazada. ¿Está abierta la página web del ACT350 u otra app conectada?"
        is NoRouteToHostException -> "No se encuentra el equipo en la red. Revise el Wi-Fi"
        else -> e.message ?: e.javaClass.simpleName
    }

    companion object {
        const val CONNECT_TIMEOUT_MS = 3_000
        const val READ_TIMEOUT_MS = 2_000
    }
}
