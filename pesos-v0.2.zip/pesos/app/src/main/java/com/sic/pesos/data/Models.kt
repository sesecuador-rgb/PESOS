package com.sic.pesos.data

enum class WeightMode(val label: String) { GROSS("Peso bruto"), NET("Peso neto") }

data class TestRecord(
    val id: Long,
    val number: Int,
    val startedAt: Long,
    val finishedAt: Long?,
    val mode: WeightMode,
    val count: Int = 0,
    val totalKg: Double = 0.0,
)

data class Weighing(
    val id: Long,
    val testId: Long,
    val seq: Int,
    val kg: Double,
    /** Momento en que se alcanzó el máximo estable del ciclo. */
    val atMs: Long,
    val cycleId: String,
)

/** Lo único que la lógica de pesaje necesita del almacenamiento. */
interface WeighingStore {
    /**
     * Guarda la pesada si ese ciclo (cycleId) aún no fue guardado.
     * Devuelve la pesada guardada, o null si ya existía (evita duplicados).
     */
    fun saveWeighing(testId: Long, cycleId: String, kg: Double, atMs: Long): Weighing?
}
