package com.sic.pesos.cycle

import com.sic.pesos.data.WeighingStore
import com.sic.pesos.data.Weighing
import com.sic.pesos.data.WeightMode
import com.sic.pesos.sics.SicsParser
import com.sic.pesos.sics.SicsResponse
import com.sic.pesos.sics.WeightStatus

/**
 * Une las tres piezas: respuesta MT-SICS → muestra en kg (bruto o neto) →
 * detector de ciclos → almacenamiento. Sin Android: se prueba con JUnit.
 */
class WeighingSession(
    private val store: WeighingStore,
    val detector: CycleDetector,
) {
    var testId: Long? = null
        private set
    var mode: WeightMode = WeightMode.GROSS
        private set

    fun start(testId: Long, mode: WeightMode) {
        this.testId = testId
        this.mode = mode
        detector.reset()
    }

    fun stop() {
        testId = null
        detector.reset()
    }

    /** Devuelve las pesadas que quedaron guardadas con esta respuesta (0 o 1). */
    fun onResponse(timeMs: Long, response: SicsResponse): List<Weighing> {
        val id = testId ?: return emptyList()
        val events = detector.onSample(toSample(timeMs, response, mode))
        return events.filterIsInstance<CycleEvent.Completed>()
            .mapNotNull { store.saveWeighing(id, it.cycleId, it.kg, it.maxAtMs) }
    }

    fun onLinkLost(timeMs: Long) {
        if (testId != null) detector.onLinkLost(timeMs)
    }

    /** Finalizar con carga puesta: save = true guarda el máximo estable del ciclo actual. */
    fun closeCycle(timeMs: Long, save: Boolean): Weighing? {
        val id = testId ?: return null
        val ev = detector.closeNow(timeMs)
        return if (save && ev is CycleEvent.Completed) store.saveWeighing(id, ev.cycleId, ev.kg, ev.maxAtMs) else null
    }

    companion object {
        fun toSample(timeMs: Long, response: SicsResponse, mode: WeightMode): WeightSample {
            val r = (response as? SicsResponse.Six1)?.reading
                ?: return WeightSample(timeMs, SampleKind.INVALID, null)
            val kind = when (r.status) {
                WeightStatus.STABLE -> SampleKind.STABLE
                WeightStatus.DYNAMIC -> SampleKind.DYNAMIC
                WeightStatus.OVERLOAD -> SampleKind.OVERLOAD
                WeightStatus.UNDERLOAD -> SampleKind.UNDERLOAD
                else -> SampleKind.INVALID
            }
            val value = if (mode == WeightMode.GROSS) r.gross else r.net
            val kg = if (r.complete && value != null) SicsParser.toKg(value, r.unit!!) else null
            val finalKind = if (kg == null && (kind == SampleKind.STABLE || kind == SampleKind.DYNAMIC)) {
                SampleKind.INVALID
            } else kind
            return WeightSample(timeMs, finalKind, kg)
        }
    }
}
