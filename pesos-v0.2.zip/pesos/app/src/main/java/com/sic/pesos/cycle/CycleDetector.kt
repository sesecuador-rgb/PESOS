package com.sic.pesos.cycle

import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToLong

/**
 * Detección de ciclos de carga. No depende de Android ni de la red: recibe
 * muestras (tiempo, estado, peso en kg) y decide cuándo empieza y termina cada ciclo.
 *
 * Reglas:
 *  - Un ciclo empieza cuando el peso válido alcanza [CycleConfig.minLoadKg].
 *  - Dentro del ciclo solo cuentan valores que el ACT350 marca como estables (Sts = S).
 *    Por defecto basta 1 lectura S (el ACT350 ya hizo su propia detección de movimiento);
 *    [CycleConfig.stableSamples] permite exigir más lecturas seguidas dentro de ± 1 división.
 *    Se conserva el MAYOR de esos valores (5 → 7 → 20 kg deja 20 kg).
 *  - El ciclo termina en cuanto el ACT350 reporta peso ESTABLE dentro de la banda de cero,
 *    o si el peso permanece en la banda (aunque inestable) durante [CycleConfig.unloadConfirmMs].
 *    Recién ahí se emite [CycleEvent.Completed].
 *  - Sobrecarga, bajo cero, inválido o sin conexión nunca cuentan como peso ni como descarga.
 */

enum class SampleKind { STABLE, DYNAMIC, OVERLOAD, UNDERLOAD, INVALID }

data class WeightSample(val timeMs: Long, val kind: SampleKind, val weightKg: Double?)

data class CycleConfig(
    val divisionKg: Double,
    val minLoadKg: Double,
    val zeroBandKg: Double,
    val stableSamples: Int,
    val stableToleranceKg: Double,
    val unloadConfirmMs: Long,
) {
    fun validate(): String? = when {
        divisionKg <= 0.0 -> "La división debe ser mayor que 0"
        zeroBandKg < 0.0 -> "La banda de cero no puede ser negativa"
        minLoadKg <= zeroBandKg -> "La carga mínima debe ser mayor que la banda de cero"
        stableSamples < 1 -> "Las lecturas estables deben ser al menos 1"
        stableToleranceKg < 0.0 -> "La tolerancia no puede ser negativa"
        unloadConfirmMs < 0 -> "El tiempo de descarga no puede ser negativo"
        else -> null
    }

    companion object {
        /**
         * Valores iniciales a partir de la división d:
         *  - carga mínima = 20 d (carga mínima habitual de una balanza clase III)
         *  - banda de cero = 5 d
         *  - 1 lectura estable del ACT350 (tolerancia 1 d si se exigen más)
         *  - cierre al volver estable a cero, o 0,8 s cerca de cero aunque oscile
         */
        fun suggested(divisionKg: Double) = CycleConfig(
            divisionKg = divisionKg,
            minLoadKg = roundTo(20 * divisionKg, divisionKg),
            zeroBandKg = roundTo(5 * divisionKg, divisionKg),
            stableSamples = 1,
            stableToleranceKg = divisionKg,
            unloadConfirmMs = 800,
        )

        private fun roundTo(v: Double, step: Double) = (v / step).roundToLong() * step
    }
}

enum class CyclePhase { WAITING_LOAD, LOADED }

enum class CycleWarning(val text: String) {
    PARTIAL_UNLOAD("La carga bajó pero no volvió a cero. Descargue completamente la celda para cerrar la pesada."),
    LINK_LOST_IN_CYCLE("Se perdió la conexión con carga puesta. El ciclo continúa; si cambió el objeto, descargue la celda."),
    OVERLOAD("Sobrecarga: el valor no se registra."),
    UNDERLOAD("Bajo cero: haga cero en el ACT350."),
    INVALID("Lectura no válida: se ignora."),
}

data class CycleSnapshot(
    val phase: CyclePhase,
    val cycleId: String?,
    val maxStableKg: Double?,
    val maxStableAtMs: Long?,
    val warning: CycleWarning?,
    val unloading: Boolean,
) {
    companion object {
        val EMPTY = CycleSnapshot(CyclePhase.WAITING_LOAD, null, null, null, null, false)
    }
}

sealed class CycleEvent {
    data class Started(val cycleId: String, val timeMs: Long) : CycleEvent()
    data class NewMax(val cycleId: String, val kg: Double, val timeMs: Long) : CycleEvent()
    data class Completed(val cycleId: String, val kg: Double, val maxAtMs: Long, val closedAtMs: Long) : CycleEvent()
    data class Discarded(val cycleId: String, val reason: String) : CycleEvent()
}

class CycleDetector(
    var config: CycleConfig,
    private val newId: () -> String = { UUID.randomUUID().toString() },
) {
    private var phase = CyclePhase.WAITING_LOAD
    private var cycleId: String? = null
    private var maxKg: Double? = null
    private var maxAt: Long? = null
    private var lastStableKg: Double? = null
    private var stableRun = 0
    private var nearZeroSince: Long? = null
    private var warning: CycleWarning? = null
    private var linkLostInCycle = false

    fun snapshot() = CycleSnapshot(phase, cycleId, maxKg, maxAt, warning, nearZeroSince != null)

    fun reset() {
        resetCycle()
        warning = null
    }

    fun onSample(s: WeightSample): List<CycleEvent> {
        val c = config
        val w = s.weightKg

        if (s.kind == SampleKind.OVERLOAD || s.kind == SampleKind.UNDERLOAD ||
            s.kind == SampleKind.INVALID || w == null
        ) {
            breakStable()
            nearZeroSince = null
            warning = when (s.kind) {
                SampleKind.OVERLOAD -> CycleWarning.OVERLOAD
                SampleKind.UNDERLOAD -> CycleWarning.UNDERLOAD
                else -> CycleWarning.INVALID
            }
            return emptyList()
        }

        val events = mutableListOf<CycleEvent>()

        if (phase == CyclePhase.WAITING_LOAD) {
            warning = null
            if (w < c.minLoadKg) {
                breakStable()
                return events
            }
            phase = CyclePhase.LOADED
            cycleId = newId()
            maxKg = null
            maxAt = null
            linkLostInCycle = false
            breakStable()
            nearZeroSince = null
            events += CycleEvent.Started(cycleId!!, s.timeMs)
        }

        // ---- Ciclo en curso ----
        if (w <= c.zeroBandKg) {
            breakStable()
            if (s.kind == SampleKind.STABLE) {
                // El ACT350 confirma que la celda quedó quieta cerca de cero: descarga segura.
                events += closeCycle(s.timeMs)
                return events
            }
            val since = nearZeroSince ?: s.timeMs.also { nearZeroSince = it }
            if (s.timeMs - since >= c.unloadConfirmMs) {
                events += closeCycle(s.timeMs)
            }
            return events
        }
        nearZeroSince = null

        if (s.kind == SampleKind.STABLE) {
            val last = lastStableKg
            stableRun = if (last != null && abs(w - last) <= c.stableToleranceKg + EPS) stableRun + 1 else 1
            lastStableKg = w
            if (stableRun >= c.stableSamples && w >= c.minLoadKg) {
                val m = maxKg
                if (m == null || w > m + EPS) {
                    maxKg = w
                    maxAt = s.timeMs
                    events += CycleEvent.NewMax(cycleId!!, w, s.timeMs)
                }
            }
        } else {
            breakStable()
        }

        val m = maxKg
        warning = when {
            m != null && w < m - c.minLoadKg -> CycleWarning.PARTIAL_UNLOAD
            linkLostInCycle -> CycleWarning.LINK_LOST_IN_CYCLE
            else -> null
        }
        return events
    }

    /** Corte de comunicación: no se toma como descarga ni como carga nueva. */
    fun onLinkLost(@Suppress("UNUSED_PARAMETER") timeMs: Long) {
        breakStable()
        nearZeroSince = null
        if (phase == CyclePhase.LOADED) {
            linkLostInCycle = true
            warning = CycleWarning.LINK_LOST_IN_CYCLE
        }
    }

    /** Cierra el ciclo actual sin esperar la descarga (Finalizar con carga puesta). */
    fun closeNow(timeMs: Long): CycleEvent? =
        if (phase == CyclePhase.LOADED) closeCycle(timeMs) else null

    private fun closeCycle(timeMs: Long): CycleEvent {
        val id = cycleId!!
        val m = maxKg
        val at = maxAt
        val ev = if (m != null && at != null) {
            CycleEvent.Completed(id, m, at, timeMs)
        } else {
            CycleEvent.Discarded(id, "No hubo peso estable en el ciclo")
        }
        resetCycle()
        warning = null
        return ev
    }

    private fun resetCycle() {
        phase = CyclePhase.WAITING_LOAD
        cycleId = null
        maxKg = null
        maxAt = null
        linkLostInCycle = false
        nearZeroSince = null
        breakStable()
    }

    private fun breakStable() {
        stableRun = 0
        lastStableKg = null
    }

    private companion object {
        const val EPS = 1e-9
    }
}
