package com.sic.pesos.report

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.sic.pesos.data.TestRecord
import com.sic.pesos.data.Weighing
import java.io.File
import java.io.FileOutputStream

/** Reporte PDF A4 sin gráfica: identificación, tabla de pesadas, cantidad y suma. */
object PdfReport {
    private const val W = 595
    private const val H = 842
    private const val M = 44f
    private const val ROW = 20f

    fun write(
        context: Context,
        test: TestRecord,
        list: List<Weighing>,
        decimals: Int,
        deviceLabel: String,
    ): File {
        val doc = PdfDocument()

        val title = Paint().apply { textSize = 18f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
        val bold = Paint().apply { textSize = 11f; typeface = Typeface.DEFAULT_BOLD; color = Color.BLACK; isAntiAlias = true }
        val body = Paint().apply { textSize = 11f; color = Color.BLACK; isAntiAlias = true }
        val small = Paint().apply { textSize = 9f; color = Color.DKGRAY; isAntiAlias = true }
        val line = Paint().apply { color = Color.rgb(160, 160, 160); strokeWidth = 0.8f }
        val shade = Paint().apply { color = Color.rgb(232, 237, 242) }
        val right = { p: Paint -> Paint(p).apply { textAlign = Paint.Align.RIGHT } }

        // Columnas: N° | Fecha | Hora | Peso (kg)
        val xN = M
        val xFecha = M + 60f
        val xHora = M + 190f
        val xPesoR = W - M

        var pageNo = 0
        var page: PdfDocument.Page? = null
        var c: Canvas? = null
        var y = 0f

        fun tableHeader() {
            c!!.drawRect(M, y - 14f, W - M, y + 6f, shade)
            c!!.drawText("N°", xN + 4f, y, bold)
            c!!.drawText("Fecha", xFecha, y, bold)
            c!!.drawText("Hora", xHora, y, bold)
            c!!.drawText("Peso (kg)", xPesoR - 4f, y, right(bold))
            y += ROW
        }

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            c = page!!.canvas
            y = M + 10f
            c!!.drawText("Reporte de prueba de pesaje", M, y, title)
            c!!.drawText("Página $pageNo", W - M, y, right(small))
            y += 26f
            if (pageNo == 1) {
                val rows = listOf(
                    "Prueba N°" to test.number.toString(),
                    "Inicio" to Fmt.dateTime(test.startedAt),
                    "Fin" to (test.finishedAt?.let { Fmt.dateTime(it) } ?: "En curso"),
                    "Valor registrado" to test.mode.label,
                    "Equipo" to deviceLabel,
                )
                rows.forEach { (k, v) ->
                    c!!.drawText(k, M, y, bold)
                    c!!.drawText(v, M + 120f, y, body)
                    y += 16f
                }
                y += 12f
            }
            tableHeader()
        }

        newPage()
        if (list.isEmpty()) {
            c!!.drawText("Sin pesadas registradas.", M, y, body)
            y += ROW
        }
        list.forEach { w ->
            if (y > H - M - 70f) newPage()
            c!!.drawText(w.seq.toString(), xN + 4f, y, body)
            c!!.drawText(Fmt.date(w.atMs), xFecha, y, body)
            c!!.drawText(Fmt.time(w.atMs), xHora, y, body)
            c!!.drawText(Fmt.kg(w.kg, decimals), xPesoR - 4f, y, right(body))
            c!!.drawLine(M, y + 6f, W - M, y + 6f, line)
            y += ROW
        }

        if (y > H - M - 60f) newPage()
        y += 10f
        c!!.drawLine(M, y - 12f, W - M, y - 12f, Paint(line).apply { strokeWidth = 1.5f; color = Color.BLACK })
        c!!.drawText("Cantidad total de pesadas", M, y, bold)
        c!!.drawText(list.size.toString(), xPesoR - 4f, y, right(bold))
        y += 18f
        c!!.drawText("Suma total (kg)", M, y, bold)
        c!!.drawText(Fmt.total(list, decimals), xPesoR - 4f, y, right(bold))
        y += 28f
        c!!.drawText("Generado por Pesos el ${Fmt.dateTime(System.currentTimeMillis())}", M, y, small)

        page?.let { doc.finishPage(it) }

        val dir = File(context.filesDir, "reportes").apply { mkdirs() }
        val file = File(dir, "Prueba_${test.number}_${Fmt.fileStamp(test.startedAt)}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }
}
