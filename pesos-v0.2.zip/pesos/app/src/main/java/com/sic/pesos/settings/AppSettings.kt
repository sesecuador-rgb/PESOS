package com.sic.pesos.settings

import android.content.Context
import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.data.WeightMode
import java.math.BigDecimal

data class Settings(
    val host: String = "192.168.0.10",
    val port: Int = 81,
    val pollMs: Long = 100,
    val divisionKg: Double = 0.01,
    val minLoadKg: Double = 0.2,
    val zeroBandKg: Double = 0.05,
    val stableSamples: Int = 1,
    val unloadConfirmMs: Long = 800,
    val weightMode: WeightMode = WeightMode.GROSS,
    val autoConnect: Boolean = true,
) {
    fun cycleConfig() = CycleConfig(
        divisionKg = divisionKg,
        minLoadKg = minLoadKg,
        zeroBandKg = zeroBandKg,
        stableSamples = stableSamples,
        stableToleranceKg = divisionKg,
        unloadConfirmMs = unloadConfirmMs,
    )

    /** Decimales a mostrar según la división (0.01 → 2, 0.5 → 1, 1 → 0). */
    val decimals: Int
        get() = runCatching {
            BigDecimal(divisionKg.toString()).stripTrailingZeros().scale().coerceIn(0, 4)
        }.getOrDefault(2)

    fun validate(): String? = when {
        host.isBlank() -> "Escriba la IP del ACT350"
        port !in 1..65535 -> "Puerto no válido"
        pollMs < 100 -> "El intervalo de consulta debe ser de al menos 100 ms"
        else -> cycleConfig().validate()
    }

    fun withSuggestedThresholds(): Settings {
        val s = CycleConfig.suggested(divisionKg)
        return copy(
            minLoadKg = s.minLoadKg,
            zeroBandKg = s.zeroBandKg,
            stableSamples = s.stableSamples,
            unloadConfirmMs = s.unloadConfirmMs,
        )
    }
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("pesos_ajustes", Context.MODE_PRIVATE)

    fun load(): Settings {
        val d = Settings()
        if (prefs.getInt("schema", 1) < 2) {
            // v0.2: captura más rápida. Se reemplazan los valores lentos de la v0.1.
            prefs.edit()
                .putLong("pollMs", d.pollMs)
                .putInt("stableSamples", d.stableSamples)
                .putLong("unloadConfirmMs", d.unloadConfirmMs)
                .putInt("schema", 2)
                .apply()
        }
        return Settings(
            host = prefs.getString("host", d.host) ?: d.host,
            port = prefs.getInt("port", d.port),
            pollMs = prefs.getLong("pollMs", d.pollMs),
            divisionKg = prefs.getFloat("divisionKg", d.divisionKg.toFloat()).toString().toDouble(),
            minLoadKg = prefs.getFloat("minLoadKg", d.minLoadKg.toFloat()).toString().toDouble(),
            zeroBandKg = prefs.getFloat("zeroBandKg", d.zeroBandKg.toFloat()).toString().toDouble(),
            stableSamples = prefs.getInt("stableSamples", d.stableSamples),
            unloadConfirmMs = prefs.getLong("unloadConfirmMs", d.unloadConfirmMs),
            weightMode = runCatching {
                WeightMode.valueOf(prefs.getString("weightMode", d.weightMode.name)!!)
            }.getOrDefault(d.weightMode),
            autoConnect = prefs.getBoolean("autoConnect", d.autoConnect),
        )
    }

    fun save(s: Settings) {
        prefs.edit()
            .putString("host", s.host.trim())
            .putInt("port", s.port)
            .putLong("pollMs", s.pollMs)
            .putFloat("divisionKg", s.divisionKg.toFloat())
            .putFloat("minLoadKg", s.minLoadKg.toFloat())
            .putFloat("zeroBandKg", s.zeroBandKg.toFloat())
            .putInt("stableSamples", s.stableSamples)
            .putLong("unloadConfirmMs", s.unloadConfirmMs)
            .putString("weightMode", s.weightMode.name)
            .putBoolean("autoConnect", s.autoConnect)
            .apply()
    }
}
