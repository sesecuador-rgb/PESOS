package com.sic.pesos

import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.cycle.CycleDetector
import com.sic.pesos.cycle.CyclePhase
import com.sic.pesos.cycle.WeighingSession
import com.sic.pesos.data.Weighing
import com.sic.pesos.data.WeighingStore
import com.sic.pesos.data.WeightMode
import com.sic.pesos.sics.SicsParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

/** Almacén en memoria con la misma regla que SQLite: cycle_id único. */
class FakeStore : WeighingStore {
    val rows = mutableListOf<Weighing>()
    override fun saveWeighing(testId: Long, cycleId: String, kg: Double, atMs: Long): Weighing? {
        if (rows.any { it.cycleId == cycleId }) return null
        val seq = (rows.filter { it.testId == testId }.maxOfOrNull { it.seq } ?: 0) + 1
        return Weighing(rows.size + 1L, testId, seq, kg, atMs, cycleId).also { rows += it }
    }
}

/**
 * Las secuencias se alimentan con respuestas SIX1 con el formato real del manual,
 * así se prueba junto: lector MT-SICS → detector de ciclos → almacenamiento.
 * Configuración: división 0.01 kg → carga mínima 0.20 kg, banda de cero 0.05 kg,
 * 1 lectura estable, cierre con cero estable (o 800 ms cerca de cero). Sondeo cada 250 ms.
 */
class WeighingSessionTest {
    private lateinit var store: FakeStore
    private lateinit var session: WeighingSession
    private var clock = 0L
    private var ids = 0

    @Before
    fun setUp() {
        store = FakeStore()
        session = WeighingSession(store, CycleDetector(CycleConfig.suggested(0.01)) { "ciclo-${++ids}" })
        session.start(testId = 1, mode = WeightMode.GROSS)
        clock = 0
    }

    private fun line(sts: String, g: Double, n: Double = g, t: Double = 0.0) =
        "SIX1 $sts 0 N N R 0 0 0 1 N %10.2f %10.2f %10.2f kg\r\n".format(java.util.Locale.US, g, n, t)

    /** Envía [times] respuestas iguales y devuelve lo que se guardó. */
    private fun feed(sts: String, kg: Double, times: Int = 1, net: Double = kg, tare: Double = 0.0): List<Weighing> {
        val out = mutableListOf<Weighing>()
        repeat(times) {
            clock += 250
            out += session.onResponse(clock, SicsParser.parse(line(sts, kg, net, tare)))
        }
        return out
    }

    private fun unload() = feed("D", 0.0) + feed("S", 0.0, 6)
    private fun total() = store.rows.sumOf { it.kg }

    @Test
    fun cinco_siete_veinte_en_un_mismo_ciclo_guarda_solo_20() {
        feed("S", 0.0, 4)
        feed("D", 5.0, 2); feed("S", 5.0, 4)
        feed("D", 7.0, 2); feed("S", 7.0, 4)
        feed("D", 20.0, 2)
        val momentoDelMaximo = clock + 250           // primera lectura estable de 20 kg
        feed("S", 20.0, 5)
        assertEquals("Nada se guarda mientras la carga sigue puesta", 0, store.rows.size)
        assertEquals(20.0, session.detector.snapshot().maxStableKg!!, 1e-9)

        unload()
        assertEquals(1, store.rows.size)
        assertEquals(20.0, store.rows[0].kg, 1e-9)
        assertEquals(1, store.rows[0].seq)
        assertEquals(momentoDelMaximo, store.rows[0].atMs)
    }

    @Test
    fun retirar_a_cero_y_cargar_7_crea_la_pesada_siguiente() {
        feed("S", 0.0, 4)
        feed("D", 20.0, 2); feed("S", 20.0, 4); unload()
        feed("D", 7.0, 2); feed("S", 7.0, 4); unload()
        assertEquals(2, store.rows.size)
        assertEquals(2, store.rows[1].seq)
        assertEquals(7.0, store.rows[1].kg, 1e-9)
    }

    @Test
    fun ejemplo_5_7_20_en_ciclos_separados_suma_32() {
        feed("S", 0.0, 4)
        for (kg in listOf(5.0, 7.0, 20.0)) { feed("D", kg, 2); feed("S", kg, 4); unload() }
        assertEquals(listOf(5.0, 7.0, 20.0), store.rows.map { it.kg })
        assertEquals(32.0, total(), 1e-9)
    }

    @Test
    fun valores_inestables_no_se_guardan() {
        feed("S", 0.0, 4)
        feed("D", 15.0, 12)                  // nunca se estabiliza
        unload()
        assertEquals(0, store.rows.size)
    }

    @Test
    fun pico_inestable_no_reemplaza_el_maximo_estable() {
        feed("S", 0.0, 4)
        feed("S", 20.0, 4)
        feed("D", 25.0, 3)                   // golpe/rebote
        feed("S", 20.0, 4)
        unload()
        assertEquals(1, store.rows.size)
        assertEquals(20.0, store.rows[0].kg, 1e-9)
    }

    @Test
    fun carga_rapida_con_una_sola_lectura_estable_se_registra() {
        // Caso del video: se coloca, el ACT350 marca estable un instante y se retira.
        feed("S", 0.0, 4)
        feed("D", 1.4, 1); feed("D", 2.6, 1)
        feed("S", 2.8, 1)
        feed("D", 1.6, 1); feed("D", 0.2, 1)
        feed("S", 0.0, 1)                    // cero estable: cierra de inmediato
        assertEquals(2.8, store.rows.single().kg, 1e-9)
    }

    @Test
    fun pesadas_seguidas_rapidas_no_se_pierden() {
        feed("S", 0.0, 2)
        for (i in 1..5) {
            feed("D", 2.4, 1); feed("S", 2.8, 1); feed("D", 1.8, 1)
            feed("S", 0.0, 1)                // apenas medio segundo en cero
        }
        assertEquals(5, store.rows.size)
        assertEquals(listOf(1, 2, 3, 4, 5), store.rows.map { it.seq })
    }

    @Test
    fun exigir_mas_lecturas_estables_es_configurable() {
        session.detector.config = CycleConfig.suggested(0.01).copy(stableSamples = 3)
        feed("S", 0.0, 4)
        feed("S", 9.0, 2); feed("D", 9.5, 1)  // solo 2 estables seguidas: no cuentan
        feed("S", 8.0, 4)
        unload()
        assertEquals(8.0, store.rows.single().kg, 1e-9)
    }

    @Test
    fun desconexion_y_reconexion_no_duplican_registros() {
        feed("S", 0.0, 4)
        feed("S", 20.0, 4)
        session.onLinkLost(clock)            // corte de Wi-Fi con carga puesta
        clock += 5_000
        feed("S", 20.0, 4)                   // reconecta: sigue el mismo objeto
        unload()
        assertEquals(1, store.rows.size)

        session.onLinkLost(clock)            // corte ya descargado
        clock += 5_000
        feed("S", 0.0, 8)
        assertEquals(1, store.rows.size)

        // Aunque el mismo ciclo se intentara guardar otra vez, no se duplica.
        val r = store.rows[0]
        assertNull(store.saveWeighing(1, r.cycleId, r.kg, r.atMs))
        assertEquals(1, store.rows.size)
    }

    @Test
    fun corte_cerca_de_cero_no_se_toma_como_descarga() {
        feed("S", 0.0, 4)
        feed("S", 20.0, 4)
        feed("D", 0.0, 2)                    // 500 ms cerca de cero, aún oscilando...
        session.onLinkLost(clock)            // ...y se corta: el conteo se reinicia
        feed("S", 20.0, 4)                   // al volver sigue la carga
        assertEquals(0, store.rows.size)
        unload()
        assertEquals(1, store.rows.size)
    }

    @Test
    fun rebote_breve_cerca_de_cero_no_duplica() {
        feed("S", 0.0, 4)
        feed("S", 20.0, 4)
        feed("D", 0.0, 2)                    // rebote inestable de 500 ms < 800 ms
        feed("S", 20.0, 4)
        unload()
        assertEquals(1, store.rows.size)
    }

    @Test
    fun sin_descargar_no_se_inventan_pesadas() {
        feed("S", 0.0, 4)
        feed("S", 20.0, 4)
        feed("S", 30.0, 40)                  // se agrega carga sin retirar la anterior
        assertEquals(0, store.rows.size)
        assertEquals(CyclePhase.LOADED, session.detector.snapshot().phase)
        unload()
        assertEquals(30.0, store.rows.single().kg, 1e-9)
    }

    @Test
    fun sobrecarga_negativo_y_bajo_umbral_no_se_guardan() {
        feed("S", 0.0, 4)
        repeat(6) { clock += 250; session.onResponse(clock, SicsParser.parse("SIX1 +\r\n")) }
        feed("S", -3.0, 6)
        feed("S", 0.10, 6); unload()         // 0.10 kg < carga mínima 0.20 kg
        assertEquals(0, store.rows.size)
    }

    @Test
    fun registro_en_neto() {
        session.start(testId = 2, mode = WeightMode.NET)
        feed("S", 5.0, 4, net = 0.0, tare = 5.0)     // recipiente tarado
        feed("S", 25.5, 4, net = 20.5, tare = 5.0)
        feed("S", 5.0, 6, net = 0.0, tare = 5.0)      // neto vuelve a 0
        assertEquals(20.5, store.rows.single().kg, 1e-9)
    }

    @Test
    fun finalizar_con_carga_puesta_guarda_el_ciclo_actual() {
        feed("S", 0.0, 4)
        feed("S", 12.0, 4)
        val w = session.closeCycle(clock, save = true)
        assertEquals(12.0, w!!.kg, 1e-9)
        assertEquals(1, store.rows.size)
    }
}
