package com.sic.pesos

import com.sic.pesos.sics.SicsParser
import com.sic.pesos.sics.SicsResponse
import com.sic.pesos.sics.WeightStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SicsParserTest {

    private fun six1(line: String) = (SicsParser.parse(line) as SicsResponse.Six1).reading

    @Test
    fun ejemplo_del_manual_B34() {
        val r = six1("SIX1 S 0 Z N R 0 0 0 1 N 0.00 0.00 0.00 kg\r\n")
        assertEquals(WeightStatus.STABLE, r.status)
        assertEquals(true, r.centerOfZero)
        assertEquals(true, r.newValue)
        assertEquals("N", r.tareMode)
        assertEquals(0.0, r.gross!!, 1e-9)
        assertEquals("kg", r.unit)
        assertEquals(2, r.decimals)
    }

    @Test
    fun bruto_neto_y_tara_no_se_confunden_con_espacios_de_relleno() {
        val r = six1("SIX1 D 0 N R R 0 0 0 1 M      25.50      20.50       5.00 kg\r\n")
        assertEquals(WeightStatus.DYNAMIC, r.status)
        assertEquals(25.50, r.gross!!, 1e-9)
        assertEquals(20.50, r.net!!, 1e-9)
        assertEquals(5.00, r.tare!!, 1e-9)
        assertEquals(false, r.newValue)
        assertEquals("M", r.tareMode)
    }

    @Test
    fun negativo_se_lee_con_signo() {
        val r = six1("SIX1 S 0 N N R 0 0 0 1 N -0.02 -0.02 0.00 kg")
        assertEquals(-0.02, r.gross!!, 1e-9)
    }

    @Test
    fun respuesta_corta_conserva_estado_pero_sin_pesos() {
        val r = six1("SIX1 +\r\n")
        assertEquals(WeightStatus.OVERLOAD, r.status)
        assertFalse(r.complete)
        assertNull(r.gross)
    }

    @Test
    fun cantidad_de_campos_inesperada_no_se_adivina() {
        val r = six1("SIX1 S 0 N N R 0 0 0 1 N 1.00 1.00 kg")
        assertFalse(r.complete)
    }

    @Test
    fun errores_mt_sics() {
        val e = SicsParser.parse("ES\r\n")
        assertTrue(e is SicsResponse.Error)
        assertEquals("ES", (e as SicsResponse.Error).code)
    }

    @Test
    fun conversion_a_kg() {
        assertEquals(1.5, SicsParser.toKg(1500.0, "g")!!, 1e-9)
        assertEquals(0.45359237, SicsParser.toKg(1.0, "lb")!!, 1e-12)
        assertNull(SicsParser.toKg(1.0, "xx"))
    }
}
