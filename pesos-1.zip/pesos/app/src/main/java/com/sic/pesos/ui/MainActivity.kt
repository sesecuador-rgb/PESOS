package com.sic.pesos.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sic.pesos.cycle.CyclePhase
import com.sic.pesos.data.WeightMode
import com.sic.pesos.report.Fmt
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.WeightStatus
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val vm: PesosViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La tablet no se apaga mientras la app está abierta: el registro no se interrumpe.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { PesosTheme { PesosApp(vm) } }
    }
}

@Composable
fun PesosApp(vm: PesosViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    LaunchedEffect(s.message) {
        s.message?.let {
            Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show()
            vm.consumeMessage()
        }
    }
    BackHandler(enabled = s.screen != Screen.MAIN) {
        vm.go(if (s.screen == Screen.HISTORY_DETAIL) Screen.HISTORY else Screen.MAIN)
    }

    Surface(Modifier.fillMaxSize(), color = Pal.Bg) {
        Column(Modifier.fillMaxSize()) {
            TopBar(s, vm)
            Box(Modifier.weight(1f)) {
                when (s.screen) {
                    Screen.MAIN -> WeighScreen(s, vm)
                    Screen.HISTORY -> HistoryScreen(s, vm)
                    Screen.HISTORY_DETAIL -> HistoryDetailScreen(s, vm)
                    Screen.SETTINGS -> SettingsScreen(s, vm)
                    Screen.DIAGNOSTICS -> DiagnosticsScreen(s, vm)
                }
            }
        }
        Dialogs(s, vm)
    }
}

@Composable
private fun TopBar(s: UiState, vm: PesosViewModel) {
    Row(
        Modifier.fillMaxWidth().background(Pal.Blue).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Pesos", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(16.dp))
        LinkPill(s.link)
        Spacer(Modifier.weight(1f))
        NavButton("Pesaje", s.screen == Screen.MAIN) { vm.go(Screen.MAIN) }
        NavButton("Historial", s.screen == Screen.HISTORY || s.screen == Screen.HISTORY_DETAIL) { vm.openHistory() }
        NavButton("Prueba de conexión", s.screen == Screen.DIAGNOSTICS) { vm.go(Screen.DIAGNOSTICS) }
        NavButton("Ajustes", s.screen == Screen.SETTINGS) { vm.go(Screen.SETTINGS) }
    }
}

@Composable
private fun NavButton(text: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            text,
            color = if (selected) Color.White else Color(0xFFB9CDE0),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 16.sp,
        )
    }
}

@Composable
fun LinkPill(link: LinkState) {
    when (link) {
        is LinkState.Connected -> Pill("Conectado ${link.target}", Pal.Green)
        is LinkState.Connecting -> Pill("Conectando…", Pal.Amber)
        is LinkState.Retrying -> Pill("Sin conexión, reintentando", Pal.Red)
        LinkState.Disconnected -> Pill("Desconectado", Pal.Red)
    }
}

// ============================ Pantalla de pesaje ============================

@Composable
private fun WeighScreen(s: UiState, vm: PesosViewModel) {
    BoxWithConstraints(Modifier.fillMaxSize().padding(16.dp)) {
        if (maxWidth > 820.dp) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1.1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LivePanel(s, vm)
                    CyclePanel(s)
                }
                TestPanel(s, vm, Modifier.weight(1f))
            }
        } else {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LivePanel(s, vm)
                CyclePanel(s)
                TestPanel(s, vm, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LivePanel(s: UiState, vm: PesosViewModel) {
    val r = s.reading
    val mode = s.activeTest?.mode ?: s.settings.weightMode
    val connected = s.link is LinkState.Connected
    val dec = r?.decimals ?: s.settings.decimals
    fun num(v: Double?) = v?.let { String.format(Locale.US, "%.${dec}f", it) } ?: "----"

    if (!connected) {
        Panel(Modifier.fillMaxWidth(), padding = 12.dp) {
            Text(
                "El ACT350 acepta una sola conexión: cierre su página web en cualquier navegador antes de conectar la app.",
                color = Pal.Red, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            )
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.connect() }) { Text("Conectar") }
            }
        }
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Pal.Readout).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(mode.label, color = Color(0xFFB9CDE0), fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            val (txt, col) = when {
                !connected || r == null -> "Sin datos" to Pal.LedOff
                r.status == WeightStatus.STABLE && r.complete -> "Estable" to Pal.Green
                r.status == WeightStatus.DYNAMIC && r.complete -> "Inestable" to Pal.Amber
                else -> r.status.label to Pal.Red
            }
            Pill(txt, col)
        }
        val shown = if (connected && r != null) (if (mode == WeightMode.GROSS) r.gross else r.net) else null
        Row(verticalAlignment = Alignment.Bottom) {
            Text(num(shown), color = Color.White, fontFamily = Digits, fontWeight = FontWeight.Bold, fontSize = 88.sp)
            Spacer(Modifier.width(12.dp))
            Text(r?.unit ?: "", color = Color.White, fontSize = 32.sp, modifier = Modifier.padding(bottom = 16.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            listOf("Bruto" to r?.gross, "Neto" to r?.net, "Tara" to r?.tare).forEach { (k, v) ->
                Column {
                    Text(k, color = Color(0xFF8FA8C0), fontSize = 14.sp)
                    Text(
                        if (connected) num(v) else "----",
                        color = Color.White, fontFamily = Digits, fontSize = 22.sp,
                    )
                }
            }
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Registrar:", color = Pal.Muted, fontSize = 16.sp)
        WeightMode.entries.forEach { m ->
            val sel = m == mode
            if (sel) Button(onClick = {}, enabled = s.activeTest == null) { Text(m.label) }
            else OutlinedButton(onClick = { vm.setMode(m) }, enabled = s.activeTest == null) { Text(m.label) }
        }
        if (s.activeTest != null) Text("(fijado al iniciar la prueba)", color = Pal.Muted, fontSize = 13.sp)
    }
    s.sicsError?.let { Text(it, color = Pal.Red, fontSize = 14.sp) }
}

@Composable
private fun CyclePanel(s: UiState) {
    val c = s.cycle
    val dec = s.settings.decimals
    val next = (s.weighings.maxOfOrNull { it.seq } ?: 0) + 1
    val hint = when {
        s.activeTest == null -> "Inicie una prueba para registrar pesadas."
        c.phase == CyclePhase.WAITING_LOAD -> "Coloque el objeto en la celda."
        c.maxStableKg == null -> "Esperando peso estable…"
        c.unloading -> "Descarga detectada, confirmando…"
        else -> "Retire la carga hasta cerca de cero para registrar la pesada $next."
    }
    Panel(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Máximo estable del ciclo (provisional)", color = Pal.Muted, fontSize = 15.sp)
                Text(
                    c.maxStableKg?.let { "${Fmt.kg(it, dec)} kg" } ?: "—",
                    fontFamily = Digits, fontWeight = FontWeight.Bold, fontSize = 40.sp, color = Pal.Ink,
                )
                Text(hint, color = Pal.Ink, fontSize = 16.sp)
                c.warning?.let { Text(it.text, color = Pal.Amber, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
            }
            CaptureLed(s.ledOn)
        }
    }
}

@Composable
private fun TestPanel(s: UiState, vm: PesosViewModel, modifier: Modifier) {
    val t = s.activeTest
    val dec = s.settings.decimals
    Panel(modifier.fillMaxWidth()) {
        if (t == null) {
            Text("No hay una prueba en curso", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Text(
                "Al iniciarla se registra automáticamente una pesada por cada objeto colocado y retirado.",
                color = Pal.Muted, fontSize = 16.sp, modifier = Modifier.padding(vertical = 8.dp),
            )
            Button(onClick = { vm.startTest() }, modifier = Modifier.height(56.dp)) {
                Text("Iniciar prueba nueva", fontSize = 18.sp)
            }
            return@Panel
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Prueba N° ${t.number}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                Text("Inicio: ${Fmt.dateTime(t.startedAt)}", color = Pal.Muted, fontSize = 15.sp)
            }
        }
        Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(32.dp)) {
            Stat("Pesadas", s.weighings.size.toString(), big = true)
            Stat("Suma acumulada", "${Fmt.total(s.weighings, dec)} kg", big = true)
        }
        val cols = listOf("N°" to 0.6f, "Fecha" to 1.4f, "Hora" to 1.2f, "Peso (kg)" to 1.4f)
        TableHeader(cols)
        val newest = s.weighings.maxOfOrNull { it.seq }
        LazyColumn(Modifier.weight(1f)) {
            items(s.weighings.sortedByDescending { it.seq }, key = { it.id }) { w ->
                TableRow(
                    listOf(
                        w.seq.toString() to 0.6f, Fmt.date(w.atMs) to 1.4f,
                        Fmt.time(w.atMs) to 1.2f, Fmt.kg(w.kg, dec) to 1.4f,
                    ),
                    highlight = s.ledOn && w.seq == newest,
                )
                HorizontalDivider(color = Pal.Line)
            }
        }
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { vm.requestClear() }, enabled = s.weighings.isNotEmpty(),
                modifier = Modifier.height(56.dp),
            ) { Text("Borrar registros", color = Pal.Red, fontSize = 17.sp) }
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.requestFinish() }, modifier = Modifier.height(56.dp)) {
                Text("Finalizar prueba", fontSize = 18.sp)
            }
        }
    }
}

// ============================ Diálogos ============================

@Composable
private fun Dialogs(s: UiState, vm: PesosViewModel) {
    val ctx = LocalContext.current
    var pendingSave by remember { mutableStateOf<File?>(null) }
    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri -> val f = pendingSave; if (uri != null && f != null) vm.saveReportTo(uri, f) }

    when (val d = s.dialog) {
        null -> Unit
        is DialogState.FinishWithLoad -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Hay carga en la celda") },
            text = {
                Text(
                    d.maxStableKg?.let {
                        "El ciclo actual tiene un máximo estable de ${Fmt.kg(it, s.settings.decimals)} kg. ¿Desea guardarlo como pesada antes de finalizar?"
                    } ?: "La carga aún no llegó a un peso estable, por lo que no se puede guardar. Puede esperar o finalizar sin ella."
                )
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") }
                    TextButton(onClick = { vm.dismissDialog(); vm.finish(saveCurrent = false) }) { Text("Finalizar sin guardarla") }
                    if (d.maxStableKg != null) {
                        Button(onClick = { vm.dismissDialog(); vm.finish(saveCurrent = true) }) { Text("Guardar y finalizar") }
                    }
                }
            },
        )
        is DialogState.ConfirmClear -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Borrar registros") },
            text = { Text("Se borrarán las ${d.count} pesadas de esta prueba y la suma volverá a 0. Esta acción no se puede deshacer.") },
            confirmButton = {
                Button(onClick = { vm.clearCurrent() }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("Borrar")
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") } },
        )
        is DialogState.ConfirmDeleteTest -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Eliminar prueba N° ${d.test.number}") },
            text = { Text("Se eliminará la prueba con sus ${d.test.count} pesadas.") },
            confirmButton = {
                Button(onClick = { vm.deleteTest(d.test) }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("Eliminar")
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") } },
        )
        DialogState.ConfirmDeleteHistory -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Borrar historial") },
            text = { Text("Se eliminarán todas las pruebas finalizadas y sus pesadas. La prueba en curso no se toca.") },
            confirmButton = {
                Button(onClick = { vm.deleteHistory() }, colors = ButtonDefaults.buttonColors(containerColor = Pal.Red)) {
                    Text("Borrar todo")
                }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialog() }) { Text("Cancelar") } },
        )
        is DialogState.ReportReady -> AlertDialog(
            onDismissRequest = { vm.dismissDialog() },
            title = { Text("Reporte de la prueba N° ${d.test.number}") },
            text = {
                Text("${d.test.count} pesadas, suma ${Fmt.kg(d.test.totalKg, s.settings.decimals)} kg.\nArchivo: ${d.file.name}")
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { vm.dismissDialog() }) { Text("Cerrar") }
                    TextButton(onClick = { openPdf(ctx, d.file) }) { Text("Abrir") }
                    TextButton(onClick = { pendingSave = d.file; saveLauncher.launch(d.file.name) }) { Text("Guardar en…") }
                    Button(onClick = { sharePdf(ctx, d.file) }) { Text("Compartir") }
                }
            },
        )
    }
}

private fun uriFor(ctx: Context, file: File) =
    FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)

fun sharePdf(ctx: Context, file: File) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uriFor(ctx, file))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Compartir reporte"))
}

fun openPdf(ctx: Context, file: File) {
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uriFor(ctx, file), "application/pdf")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        ctx.startActivity(i)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(ctx, "No hay un visor de PDF instalado; use Compartir", Toast.LENGTH_LONG).show()
    }
}
