package com.sic.pesos.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sic.pesos.cycle.CycleConfig
import com.sic.pesos.report.Fmt
import com.sic.pesos.settings.Settings
import com.sic.pesos.sics.LinkState
import com.sic.pesos.sics.SicsParser

// ============================ Historial ============================

@Composable
fun HistoryScreen(s: UiState, vm: PesosViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pruebas guardadas", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Spacer(Modifier.weight(1f))
            OutlinedButton(
                onClick = { vm.requestDeleteHistory() },
                enabled = s.history.any { it.finishedAt != null },
            ) { Text("Borrar historial", color = Pal.Red) }
        }
        Spacer(Modifier.padding(6.dp))
        if (s.history.isEmpty()) {
            Text("Aún no hay pruebas. Inicie una desde la pantalla Pesaje.", color = Pal.Muted, fontSize = 17.sp)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(s.history, key = { it.id }) { t ->
                Panel(Modifier.fillMaxWidth().clickable { vm.openDetail(t) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Prueba N° ${t.number}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                            Text("Inicio ${Fmt.dateTime(t.startedAt)}", color = Pal.Muted)
                            Text(t.mode.label, color = Pal.Muted)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${t.count} pesadas", fontSize = 17.sp, color = Pal.Ink)
                            Text(
                                "${Fmt.kg(t.totalKg, s.settings.decimals)} kg",
                                fontFamily = Digits, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Pal.Ink,
                            )
                            if (t.finishedAt == null) Pill("En curso", Pal.Amber)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryDetailScreen(s: UiState, vm: PesosViewModel) {
    val t = s.detail ?: return
    val dec = s.settings.decimals
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Prueba N° ${t.number}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
                Text("Inicio ${Fmt.dateTime(t.startedAt)}", color = Pal.Muted)
                Text("Fin ${t.finishedAt?.let { Fmt.dateTime(it) } ?: "en curso"}", color = Pal.Muted)
                Text(t.mode.label, color = Pal.Muted)
            }
            Stat("Pesadas", s.detailWeighings.size.toString())
            Spacer(Modifier.width(24.dp))
            Stat("Suma", "${Fmt.total(s.detailWeighings, dec)} kg")
        }
        Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.go(Screen.HISTORY) }) { Text("Volver") }
            Button(onClick = { vm.reportFor(t) }) { Text("Reporte PDF") }
            OutlinedButton(onClick = { vm.requestDeleteTest(t) }) { Text("Eliminar prueba", color = Pal.Red) }
        }
        Panel(Modifier.fillMaxWidth().weight(1f), padding = 0.dp) {
            val cols = listOf("N°" to 0.6f, "Fecha" to 1.4f, "Hora" to 1.2f, "Peso (kg)" to 1.4f)
            TableHeader(cols)
            LazyColumn {
                items(s.detailWeighings, key = { it.id }) { w ->
                    TableRow(
                        listOf(
                            w.seq.toString() to 0.6f, Fmt.date(w.atMs) to 1.4f,
                            Fmt.time(w.atMs) to 1.2f, Fmt.kg(w.kg, dec) to 1.4f,
                        )
                    )
                    HorizontalDivider(color = Pal.Line)
                }
            }
        }
    }
}

// ============================ Ajustes ============================

@Composable
fun SettingsScreen(s: UiState, vm: PesosViewModel) {
    val cur = s.settings
    var host by rememberSaveable { mutableStateOf(cur.host) }
    var port by rememberSaveable { mutableStateOf(cur.port.toString()) }
    var poll by rememberSaveable { mutableStateOf(cur.pollMs.toString()) }
    var division by rememberSaveable { mutableStateOf(cur.divisionKg.toString()) }
    var minLoad by rememberSaveable { mutableStateOf(cur.minLoadKg.toString()) }
    var zeroBand by rememberSaveable { mutableStateOf(cur.zeroBandKg.toString()) }
    var samples by rememberSaveable { mutableStateOf(cur.stableSamples.toString()) }
    var unloadMs by rememberSaveable { mutableStateOf(cur.unloadConfirmMs.toString()) }
    var auto by rememberSaveable { mutableStateOf(cur.autoConnect) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    fun d(x: String) = x.trim().replace(',', '.').toDoubleOrNull()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Panel(Modifier.widthIn(max = 760.dp)) {
            Text("Conexión con el ACT350", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Field("IP", host, Modifier.weight(2f), KeyboardType.Uri) { host = it }
                Field("Puerto", port, Modifier.weight(1f), KeyboardType.Number) { port = it }
                Field("Consulta cada (ms)", poll, Modifier.weight(1.3f), KeyboardType.Number) { poll = it }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = auto, onCheckedChange = { auto = it })
                Spacer(Modifier.width(8.dp))
                Text("Conectar automáticamente al abrir la app", color = Pal.Ink)
            }
        }

        Panel(Modifier.widthIn(max = 760.dp)) {
            Text("Detección de pesadas", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Text(
                "Use la misma división (incremento) configurada en el ACT350. Los valores sugeridos son: " +
                    "carga mínima 20 d, banda de cero 5 d, 3 lecturas estables seguidas y 1 s cerca de cero para confirmar la descarga.",
                color = Pal.Muted, fontSize = 15.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Field("División d (kg)", division, Modifier.weight(1f), KeyboardType.Decimal) { division = it }
                OutlinedButton(onClick = {
                    d(division)?.takeIf { it > 0 }?.let { dv ->
                        val sug = CycleConfig.suggested(dv)
                        minLoad = sug.minLoadKg.toString()
                        zeroBand = sug.zeroBandKg.toString()
                        samples = sug.stableSamples.toString()
                        unloadMs = sug.unloadConfirmMs.toString()
                    }
                }) { Text("Usar valores sugeridos") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Field("Carga mínima para registrar (kg)", minLoad, Modifier.weight(1f), KeyboardType.Decimal) { minLoad = it }
                Field("Banda cerca de cero (kg)", zeroBand, Modifier.weight(1f), KeyboardType.Decimal) { zeroBand = it }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Field("Lecturas estables seguidas", samples, Modifier.weight(1f), KeyboardType.Number) { samples = it }
                Field("Tiempo cerca de cero (ms)", unloadMs, Modifier.weight(1f), KeyboardType.Number) { unloadMs = it }
            }
            Text(
                "Carga mínima: por debajo de este peso no se inicia ni se guarda una pesada. " +
                    "Banda de cero: la celda se considera descargada dentro de este valor. " +
                    "Si hay rebotes que cierran pesadas antes de tiempo, aumente el tiempo cerca de cero.",
                color = Pal.Muted, fontSize = 14.sp,
            )
        }

        error?.let { Text(it, color = Pal.Red, fontWeight = FontWeight.Bold) }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                val new = Settings(
                    host = host.trim(),
                    port = port.trim().toIntOrNull() ?: -1,
                    pollMs = poll.trim().toLongOrNull() ?: -1,
                    divisionKg = d(division) ?: -1.0,
                    minLoadKg = d(minLoad) ?: -1.0,
                    zeroBandKg = d(zeroBand) ?: -1.0,
                    stableSamples = samples.trim().toIntOrNull() ?: -1,
                    unloadConfirmMs = unloadMs.trim().toLongOrNull() ?: -1,
                    weightMode = cur.weightMode,
                    autoConnect = auto,
                )
                error = vm.saveSettings(new)
            }) { Text("Guardar ajustes", fontSize = 17.sp) }
            OutlinedButton(onClick = { vm.go(Screen.MAIN) }) { Text("Volver") }
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    modifier: Modifier,
    type: KeyboardType,
    onChange: (String) -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        modifier = modifier,
    )
}

// ============================ Prueba de conexión ============================

@Composable
fun DiagnosticsScreen(s: UiState, vm: PesosViewModel) {
    val clipboard = LocalClipboardManager.current
    val connected = s.link is LinkState.Connected
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Panel(Modifier.fillMaxWidth()) {
            Text("Prueba de conexión MT-SICS", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Pal.Ink)
            Text(
                "1. Cierre la página web del ACT350 en el navegador (el equipo admite una sola conexión).\n" +
                    "2. Pulse Conectar y luego Enviar SIX1.\n" +
                    "3. Pulse Copiar resultado y envíelo para validar la lectura.\n" +
                    "La comunicación TCP/IP requiere firmware V1.05.0012 o superior (compruébelo con I3).",
                color = Pal.Ink, fontSize = 16.sp,
            )
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LinkPill(s.link)
                Text("${s.settings.host}:${s.settings.port}", color = Pal.Muted)
            }
            (s.link as? LinkState.Retrying)?.let { Text(it.reason, color = Pal.Red) }
            Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (s.link == LinkState.Disconnected) Button(onClick = { vm.connect() }) { Text("Conectar") }
                else OutlinedButton(onClick = { vm.disconnect() }) { Text("Desconectar") }
                Button(onClick = { vm.sendDiag("SIX1") }, enabled = connected) { Text("Enviar SIX1") }
                OutlinedButton(onClick = { vm.sendDiag("I3") }, enabled = connected) { Text("I3 firmware") }
                OutlinedButton(onClick = { vm.sendDiag("I4") }, enabled = connected) { Text("I4 n° de serie") }
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(vm.diagText())) },
                    enabled = s.diag.isNotEmpty(),
                ) { Text("Copiar resultado") }
            }
        }

        Panel(Modifier.fillMaxWidth()) {
            Text("Última respuesta del sondeo automático", fontWeight = FontWeight.Bold, color = Pal.Ink)
            Text(s.lastRaw?.let { SicsParser.visible(it) } ?: "—", fontFamily = Digits, color = Pal.Ink)
        }

        s.diag.forEach { d ->
            Panel(Modifier.fillMaxWidth()) {
                Text("${Fmt.dateTime(d.atMs)}  Enviado: ${d.command}\\r\\n", color = Pal.Muted)
                Text("Recibido: ${SicsParser.visible(d.raw)}", fontFamily = Digits, color = Pal.Ink, fontSize = 16.sp)
                HorizontalDivider(Modifier.padding(vertical = 6.dp), color = Pal.Line)
                d.table.forEach { (k, v) ->
                    Row {
                        Text(k, Modifier.width(200.dp), color = Pal.Muted)
                        Text(v, fontFamily = Digits, color = Pal.Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
